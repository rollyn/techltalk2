module go-enterprise-demo

go 1.23

require (
	github.com/gin-gonic/gin v1.10.0
	github.com/swaggo/files v1.0.1
	github.com/swaggo/gin-swagger v1.6.0
)
