package main

import (
	"net/http"

	"github.com/gin-gonic/gin"
	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"

	_ "go-enterprise-demo/docs"
)

// User represents the request body.
type User struct {
	Name  string `json:"name" binding:"required,min=2" example:"John"`
	Email string `json:"email" binding:"required,email" example:"john@example.com"`
	Age   int    `json:"age" binding:"required,gte=18" example:"30"`
}

// @title Enterprise Go Demo API
// @version 1.0
// @description Simple Gin + Swagger + input validation demo.
// @host localhost:8080
// @BasePath /
func main() {
	router := gin.Default()

	router.GET("/health", health)
	router.POST("/users", createUser)

	router.GET(
		"/swagger/*any",
		ginSwagger.WrapHandler(swaggerFiles.Handler),
	)

	if err := router.Run(":8080"); err != nil {
		panic(err)
	}
}

// health godoc
// @Summary Health check
// @Tags system
// @Produce json
// @Success 200 {object} map[string]string
// @Router /health [get]
func health(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{"status": "UP"})
}

// createUser godoc
// @Summary Create user
// @Description Accepts a user and validates name, email and age.
// @Tags users
// @Accept json
// @Produce json
// @Param user body User true "User"
// @Success 201 {object} User
// @Failure 400 {object} map[string]string
// @Router /users [post]
func createUser(c *gin.Context) {
	var user User

	if err := c.ShouldBindJSON(&user); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}

	c.JSON(http.StatusCreated, user)
}
