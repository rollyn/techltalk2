# Go Enterprise Demo

Small demo for a tech talk using:

- Gin
- Swagger / Swaggo
- JSON binding
- Input validation

## Requirements

Go 1.23+ is recommended.

## Run

```bash
go mod tidy
go run .
```

The application starts on port 8080.

## Swagger UI

Open:

http://localhost:8080/swagger/index.html

## Health check

```bash
curl http://localhost:8080/health
```

## Valid request

```bash
curl -X POST http://localhost:8080/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@example.com","age":30}'
```

## Invalid request

```bash
curl -X POST http://localhost:8080/users \
  -H "Content-Type: application/json" \
  -d '{"name":"J","email":"wrong-email","age":15}'
```

The invalid request returns HTTP 400 because the struct uses Gin validation tags:

```go
type User struct {
    Name  string `json:"name" binding:"required,min=2"`
    Email string `json:"email" binding:"required,email"`
    Age   int    `json:"age" binding:"required,gte=18"`
}
```

## Regenerate Swagger docs

The generated docs are already included, so this is optional.

```bash
go install github.com/swaggo/swag/cmd/swag@latest
swag init
```
