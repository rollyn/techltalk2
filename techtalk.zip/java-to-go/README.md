# Java Virtual Threads vs Go Goroutines Benchmark

A performance comparison between Java 21 Virtual Threads and Go Goroutines for high-concurrency workloads.

## Overview

This repository contains benchmark implementations that test three critical scenarios:
- **Pure Concurrency**: 1 million concurrent tasks with simulated I/O
- **Scalability Tests**: Tasks ranging from 100K to 5M concurrent operations
- **Variable I/O Latency**: Different I/O wait times (1ms to 100ms)

Read the full analysis in [ARTICLE.md](ARTICLE.md)

## Quick Start

### Java Spring Boot + Virtual Threads

```bash
cd java-spring-vt
./mvnw spring-boot:run
```

Server runs on `http://localhost:8080`

### Go + Gin + Goroutines

```bash
cd go-gin-goroutines
go run main.go
```

Server runs on `http://localhost:3000`

## Available Endpoints

Both implementations provide the same endpoints:

**Scenario 1 - Pure Concurrency**
- `GET /run` - 1M tasks with 20ms sleep

**Scenario 2 - Scalability Tests**
- `GET /scale/100k` - 100,000 tasks
- `GET /scale/500k` - 500,000 tasks
- `GET /scale/1m` - 1,000,000 tasks
- `GET /scale/2m` - 2,000,000 tasks
- `GET /scale/5m` - 5,000,000 tasks

**Scenario 3 - Variable I/O**
- `GET /io/1ms` - 1M tasks with 1ms sleep
- `GET /io/10ms` - 1M tasks with 10ms sleep
- `GET /io/50ms` - 1M tasks with 50ms sleep
- `GET /io/100ms` - 1M tasks with 100ms sleep

## Key Results

| Metric | Go | Java | Go Advantage |
|--------|-----|------|--------------|
| 1M tasks (20ms I/O) | 0.40s | 1.68s | 4.2x |
| 5M tasks | 1.78s | 15.31s | 8.6x |

## Test Environment

- **Hardware:** Mac Mini M4 (Apple Silicon), 10-core CPU, 16GB RAM
- **Java:** OpenJDK 21.0.5 with Spring Boot 4.0.0
- **Go:** Go 1.23.0 with Gin 1.11.0

## License

This is an educational project for performance comparison purposes.
