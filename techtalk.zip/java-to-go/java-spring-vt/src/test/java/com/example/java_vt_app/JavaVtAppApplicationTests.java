package com.example.java_vt_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JavaVtAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
