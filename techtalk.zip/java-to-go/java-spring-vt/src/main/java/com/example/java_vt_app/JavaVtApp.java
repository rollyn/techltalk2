package com.example.java_vt_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.LongAdder;

@SpringBootApplication
@RestController
public class JavaVtApp {

    public static void main(String[] args) {
        SpringApplication.run(JavaVtApp.class, args);
    }

    @GetMapping("/")
    public String home() {
        return "<pre>" +
            "Spring Boot + Virtual Threads Benchmark\n" +
            "\n" +
            "Scenario 1 - Pure Concurrency (1M tasks, 20ms sleep):\n" +
            "  GET /run\n" +
            "\n" +
            "Scenario 2 - Scalability Tests (20ms sleep):\n" +
            "  GET /scale/100k   (100,000 tasks)\n" +
            "  GET /scale/500k   (500,000 tasks)\n" +
            "  GET /scale/1m     (1,000,000 tasks)\n" +
            "  GET /scale/2m     (2,000,000 tasks)\n" +
            "  GET /scale/5m     (5,000,000 tasks)\n" +
            "\n" +
            "Scenario 3 - Variable I/O (1M tasks):\n" +
            "  GET /io/1ms       (1ms sleep)\n" +
            "  GET /io/10ms      (10ms sleep)\n" +
            "  GET /io/50ms      (50ms sleep)\n" +
            "  GET /io/100ms     (100ms sleep)\n" +
            "</pre>";
    }

    @GetMapping("/run")
    public Map<String, Object> runOneMillionTasks() {
        return runBenchmark(1_000_000, 20, "Scenario 1: Pure Concurrency");
    }

    @GetMapping("/scale/100k")
    public Map<String, Object> scale100k() {
        return runBenchmark(100_000, 20, "Scenario 2: Scale 100K");
    }

    @GetMapping("/scale/500k")
    public Map<String, Object> scale500k() {
        return runBenchmark(500_000, 20, "Scenario 2: Scale 500K");
    }

    @GetMapping("/scale/1m")
    public Map<String, Object> scale1m() {
        return runBenchmark(1_000_000, 20, "Scenario 2: Scale 1M");
    }

    @GetMapping("/scale/2m")
    public Map<String, Object> scale2m() {
        return runBenchmark(2_000_000, 20, "Scenario 2: Scale 2M");
    }

    @GetMapping("/scale/5m")
    public Map<String, Object> scale5m() {
        return runBenchmark(5_000_000, 20, "Scenario 2: Scale 5M");
    }

    @GetMapping("/io/1ms")
    public Map<String, Object> io1ms() {
        return runBenchmark(1_000_000, 1, "Scenario 3: I/O 1ms");
    }

    @GetMapping("/io/10ms")
    public Map<String, Object> io10ms() {
        return runBenchmark(1_000_000, 10, "Scenario 3: I/O 10ms");
    }

    @GetMapping("/io/50ms")
    public Map<String, Object> io50ms() {
        return runBenchmark(1_000_000, 50, "Scenario 3: I/O 50ms");
    }

    @GetMapping("/io/100ms")
    public Map<String, Object> io100ms() {
        return runBenchmark(1_000_000, 100, "Scenario 3: I/O 100ms");
    }

    private Map<String, Object> runBenchmark(int taskCount, long sleepMs, String description) {
        System.out.println("Starting " + description + ": " + taskCount + " tasks with " + sleepMs + "ms sleep");
        long start = System.nanoTime();
        LongAdder counter = new LongAdder();

        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < taskCount; i++) {
                executor.submit(() -> {
                    try { Thread.sleep(sleepMs); } catch (InterruptedException ignored) {}
                    counter.increment();
                });
            }
        }

        double seconds = (System.nanoTime() - start) / 1_000_000_000.0;
        return Map.of(
            "scenario", description,
            "tasks", taskCount,
            "sleepMs", sleepMs,
            "processed", counter.sum(),
            "seconds", String.format("%.2f", seconds),
            "tasksPerSecond", String.format("%.0f", taskCount / seconds),
            "info", "Java 21 + Spring Boot 4.0 + Virtual Threads"
        );
    }
}