package main

import (
	"fmt"
	"net/http"
	"sync"
	"sync/atomic"
	"time"

	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()

	r.GET("/", func(c *gin.Context) {
		c.String(http.StatusOK, `Go + Gin + Goroutines Benchmark

Scenario 1 - Pure Concurrency (1M tasks, 20ms sleep):
  GET /run

Scenario 2 - Scalability Tests (20ms sleep):
  GET /scale/100k   (100,000 tasks)
  GET /scale/500k   (500,000 tasks)
  GET /scale/1m     (1,000,000 tasks)
  GET /scale/2m     (2,000,000 tasks)
  GET /scale/5m     (5,000,000 tasks)

Scenario 3 - Variable I/O (1M tasks):
  GET /io/1ms       (1ms sleep)
  GET /io/10ms      (10ms sleep)
  GET /io/50ms      (50ms sleep)
  GET /io/100ms     (100ms sleep)
`)
	})

	// Scenario 1: Pure Concurrency
	r.GET("/run", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 20*time.Millisecond, "Scenario 1: Pure Concurrency")
	})

	// Scenario 2: Scalability Tests
	r.GET("/scale/100k", func(c *gin.Context) {
		runBenchmark(c, 100_000, 20*time.Millisecond, "Scenario 2: Scale 100K")
	})

	r.GET("/scale/500k", func(c *gin.Context) {
		runBenchmark(c, 500_000, 20*time.Millisecond, "Scenario 2: Scale 500K")
	})

	r.GET("/scale/1m", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 20*time.Millisecond, "Scenario 2: Scale 1M")
	})

	r.GET("/scale/2m", func(c *gin.Context) {
		runBenchmark(c, 2_000_000, 20*time.Millisecond, "Scenario 2: Scale 2M")
	})

	r.GET("/scale/5m", func(c *gin.Context) {
		runBenchmark(c, 5_000_000, 20*time.Millisecond, "Scenario 2: Scale 5M")
	})

	// Scenario 3: Variable I/O
	r.GET("/io/1ms", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 1*time.Millisecond, "Scenario 3: I/O 1ms")
	})

	r.GET("/io/10ms", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 10*time.Millisecond, "Scenario 3: I/O 10ms")
	})

	r.GET("/io/50ms", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 50*time.Millisecond, "Scenario 3: I/O 50ms")
	})

	r.GET("/io/100ms", func(c *gin.Context) {
		runBenchmark(c, 1_000_000, 100*time.Millisecond, "Scenario 3: I/O 100ms")
	})

	fmt.Println("go-gin-goroutines running → http://localhost:3000")
	r.Run(":3000")
}

func runBenchmark(c *gin.Context, taskCount int, sleepDuration time.Duration, description string) {
	fmt.Printf("Starting %s: %d tasks with %v sleep\n", description, taskCount, sleepDuration)
	start := time.Now()
	var counter int64
	var wg sync.WaitGroup

	for i := 0; i < taskCount; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			time.Sleep(sleepDuration)
			atomic.AddInt64(&counter, 1)
		}()
	}

	wg.Wait()
	elapsed := time.Since(start).Seconds()

	c.JSON(http.StatusOK, gin.H{
		"scenario":       description,
		"tasks":          taskCount,
		"sleepMs":        sleepDuration.Milliseconds(),
		"processed":      counter,
		"seconds":        fmt.Sprintf("%.2f", elapsed),
		"tasksPerSecond": fmt.Sprintf("%.0f", float64(taskCount)/elapsed),
		"info":           "Go 1.22 + Gin + Goroutines",
	})
}
